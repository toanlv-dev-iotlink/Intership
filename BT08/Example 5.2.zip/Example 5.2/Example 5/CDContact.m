//
//  CDContact.m
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "CDContact.h"
#import "CDGroup.h"


@implementation CDContact

@dynamic name;
@dynamic phone;
@dynamic avatar;
@dynamic group;

@end
