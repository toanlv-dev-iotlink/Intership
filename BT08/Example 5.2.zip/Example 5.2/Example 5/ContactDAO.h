//
//  ContactDAO.h
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "NMMainDAO.h"

@class CDGroup;

@interface ContactDAO : NMMainDAO

- (NSArray*)loadContactsByKeyword:(NSString*)keyword;
- (NSArray*)loadAllContacts;
- (void)addContact:(NSString*)name phone:(NSString*)phone group:(CDGroup*)group error:(NSError **)error;
- (void)removeAllContacts;
- (NSFetchedResultsController*)loadAllContactsController;

@end
