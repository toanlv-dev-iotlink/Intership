//
//  AddViewController.m
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "AddViewController.h"
#import "ContactDAO.h"
#import "GroupDAO.h"

@interface AddViewController ()
{
    ContactDAO *_contactDAO;
    GroupDAO *_groupDAO;
    __weak IBOutlet UITextField *_tfName;
    __weak IBOutlet UITextField *_tfPhone;
    CDGroup *_nikmeGroup;
}

@end

@implementation AddViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _contactDAO = [[ContactDAO alloc] initWithEntityName:@"CDContact"];
        _groupDAO = [[GroupDAO alloc] initWithEntityName:@"CDGroup"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.title = @"Add Contact";
    
    // init barbuttonItems
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(actionDone:)];
    self.navigationItem.rightBarButtonItem = doneButton;
    
    // init Groups
    _nikmeGroup = [_groupDAO getGroupByName:@"Nikme"];
    if(_nikmeGroup == nil)
    {
        [_groupDAO addGroup:@"Nikme"];
        _nikmeGroup = [_groupDAO getGroupByName:@"Nikme"];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - actions
- (IBAction)actionDone:(id)sender
{
    NSError *error;
    [_contactDAO addContact:_tfName.text phone:_tfPhone.text group:_nikmeGroup error:&error];
    if(error == nil)
    {
        [self.navigationController popViewControllerAnimated:YES];
    } else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:error.debugDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertView show];
    }
}

@end
