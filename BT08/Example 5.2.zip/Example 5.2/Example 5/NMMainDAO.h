//
//  NMMainDAO.h
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NMMainDAO : NSObject
{
    @protected NSString *_entityName;
}

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (NSFetchRequest*)loadRequestTemplateWithName:(NSString*)name subVars:(NSDictionary*)subVars;
- (void)saveContext;

- (id)initWithEntityName:(NSString*)name;

@end
