//
//  NSFileManager+Utilities.h
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSFileManager (Utilities)

- (NSURL*)privateDirectory;
- (NSURL*)publicDirectory;
- (NSURL*)cacheDirectory;

@end
