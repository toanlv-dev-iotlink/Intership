//
//  NMMainDAO.m
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "NMMainDAO.h"


@implementation NMMainDAO

@synthesize managedObjectContext = _managedObjectContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;


#pragma mark - init
- (id)initWithEntityName:(NSString*)name
{
    self = [self init];
    if(self)
    {
        _entityName = name;
    }
    return self;
}


#pragma mark - Core Data stack

// Create main managed object context
- (NSManagedObjectContext *)managedObjectContext
{
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    _managedObjectContext = [[NMCDManager sharedManager] managedObjectContext];
    return _managedObjectContext;
}

// Create main managed Object Model
- (NSManagedObjectModel *)managedObjectModel
{
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    _managedObjectModel = [[NMCDManager sharedManager] managedObjectModel];
    return _managedObjectModel;
}

// init persistentStoreCoordinator
- (NSPersistentStoreCoordinator *)persistentStoreCoordinator
{
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    _persistentStoreCoordinator = [[NMCDManager sharedManager] persistentStoreCoordinator];
    return _persistentStoreCoordinator;
}

#pragma mark - public methods
- (NSFetchRequest*)loadRequestTemplateWithName:(NSString*)name subVars:(NSDictionary*)subVars
{
    return [self.managedObjectModel fetchRequestFromTemplateWithName:name substitutionVariables:subVars];
}


- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        }
    }
}
@end
