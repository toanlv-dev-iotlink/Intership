//
//  RootViewController.m
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "RootViewController.h"
#import "ContactDAO.h"
#import "CDContact.h"
#import "AddViewController.h"

@interface RootViewController ()<UITableViewDataSource, UITableViewDelegate>
{
    __weak IBOutlet UITableView *_tableView;
    ContactDAO *_contactDAO;
    NSArray *_contactArray;
}

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _contactDAO = [[ContactDAO alloc] initWithEntityName:@"CDContact"];
        _contactArray = [NSArray array];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _contactArray = [_contactDAO loadAllContacts];
    
    self.navigationItem.title = @"Contacts";
    
    // init barbuttonItems
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(actionAdd:)];
    self.navigationItem.rightBarButtonItem = doneButton;
    
    UIBarButtonItem *removeButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemTrash target:self action:@selector(actionRemoveAll:)];
    self.navigationItem.leftBarButtonItem = removeButton;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    _contactArray = [_contactDAO loadAllContacts];
    [_tableView reloadData];
}

#pragma mark - actions
- (IBAction)actionAdd:(id)sender
{
    AddViewController *addVC = [[AddViewController alloc] init];
    [self.navigationController pushViewController:addVC animated:YES];
}

- (IBAction)actionRemoveAll:(id)sender
{
    [_contactDAO removeAllContacts];
    _contactArray = [_contactDAO loadAllContacts];
    [_tableView reloadData];
    
}
#pragma mark - Core Data


#pragma mark - UITableViewDataSource, UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _contactArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    
    CDContact *contact = [_contactArray objectAtIndex:indexPath.row];
    cell.textLabel.text = contact.name;
    cell.detailTextLabel.text = contact.phone;
    
    return cell;
}
@end
