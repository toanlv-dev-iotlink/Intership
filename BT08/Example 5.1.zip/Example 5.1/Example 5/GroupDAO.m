//
//  GroupDAO.m
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "GroupDAO.h"
#import "CDGroup.h"

@implementation GroupDAO

- (void)addGroup:(NSString*)name
{
    CDGroup *newGroup = (CDGroup*)[self.managedObjectContext insertNewEntityWithName:@"CDGroup"];
    newGroup.name = name;
    [self saveContext];
}

- (CDGroup*)getGroupByName:(NSString*)name
{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:_entityName inManagedObjectContext:self.managedObjectContext];
    fetchRequest.entity = entity;
    fetchRequest.predicate = [NSPredicate predicateWithFormat:@"name == %@",name];
    NSError *error;
    NSArray *fetResult = [self.managedObjectContext executeFetchRequest: fetchRequest error:&error];
    if([fetResult count] > 0) {
        return [fetResult objectAtIndex:0];
    }
    else
    {
        return nil;
    }
}

@end
