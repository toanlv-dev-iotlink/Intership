//
//  GroupDAO.h
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "NMMainDAO.h"

@class CDGroup;

@interface GroupDAO : NMMainDAO

- (void)addGroup:(NSString*)name;
- (CDGroup*)getGroupByName:(NSString*)name;

@end
