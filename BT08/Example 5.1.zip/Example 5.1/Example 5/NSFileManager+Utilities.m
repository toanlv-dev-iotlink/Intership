//
//  NSFileManager+Utilities.m
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "NSFileManager+Utilities.h"

@implementation NSFileManager (Utilities)

- (NSURL*)privateDirectory {
    return [[self URLsForDirectory:NSLibraryDirectory inDomains:NSUserDomainMask] lastObject];
}

- (NSURL*)publicDirectory {
    return [[self URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

- (NSURL*)cacheDirectory {
    return [[self URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] lastObject];
}


@end
