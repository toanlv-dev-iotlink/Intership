//
//  ContactDAO.m
//  Example 5
//
//  Created by Linh NGUYEN on 1/7/14.
//  Copyright (c) 2014 Nikmesoft Ltd. All rights reserved.
//

#import "ContactDAO.h"
#import "CDContact.h"
#import "CDGroup.h"

#define GET_CONTACTS_BY_KEYWORD     @"GET_CONTACTS_BY_KEYWORD"
#define GET_ALL_CONTACTS            @"GET_ALL_CONTACTS"

@interface ContactDAO()
{
    
}
@end

@implementation ContactDAO


#pragma mark - init
- (id)init
{
    self = [super init];
    if(self)
    {
        
    }
    return self;
}

#pragma mark - publics
- (NSArray*)loadContactsByKeyword:(NSString*)keyword
{
    NSDictionary *subVars=[NSDictionary dictionaryWithObject:keyword forKey:@"KEYWORD"];
    NSFetchRequest *fetchRequest = [self loadRequestTemplateWithName:GET_CONTACTS_BY_KEYWORD subVars:subVars];
    NSError *error;
    NSArray *fetchResults = [self.managedObjectContext executeFetchRequest: fetchRequest error:&error];
    if(error == nil)
    {
        return fetchResults;
    } else {
        return nil;
    }
}

- (NSArray*)loadAllContacts
{
    NSFetchRequest *fetchRequest = [self loadRequestTemplateWithName:GET_ALL_CONTACTS subVars:nil];
    NSError *error;
    NSArray *fetchResults = [self.managedObjectContext executeFetchRequest: fetchRequest error:&error];
    if(error == nil)
    {        return fetchResults;
    } else {
        return nil;
    }
}

- (void)addContact:(NSString*)name phone:(NSString*)phone group:(CDGroup*)group error:(NSError **)error
{
    CDContact *newContact = (CDContact*)[self.managedObjectContext insertNewEntityWithName:_entityName];
    newContact.name = name;
    newContact.phone = phone;
    newContact.group = group;
    
    NSError *insertError;
    [newContact validateForInsert:&insertError];
    if(insertError == nil)
    {
        [self saveContext];
    } else {
        [self.managedObjectContext rollback];
    }
    *error = insertError;
}

- (void)removeAllContacts
{
    NSArray *array = [self loadAllContacts];
    for (CDContact *contact in array) {
        [self.managedObjectContext deleteObject:contact];
    }
    
    [self saveContext];
}

@end
